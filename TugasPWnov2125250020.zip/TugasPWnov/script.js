let tblStandings = document.getElementById("tabelStandings")

fetch("http://127.0.0.1:5500/TugasPWnov/standings.json")
    .then(response => response.json())
    .then(data => {
        console.log(data)
        console.log(data.standings[0].table)

        data.standings[0].table.forEach(showStandings)
    })
    .catch(error => {
        console.log(error)
    });

function showStandings(value, index){
    tblStandings.innerHTML += `<tr><td>${value.position}</td><td>${value.team.name}</td><td>${value.playedGames}</td><td>${value.won}</td><td>${value.lost}</td><td>${value.draw}</td><td>${value.goalsFor}</td><td>${value.goalsAgainst}</td><td>${value.goalDifference}</td><td>${value.points}</td><td>${value.form}</td><tr>`
}